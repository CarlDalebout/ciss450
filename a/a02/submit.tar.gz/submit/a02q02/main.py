# File: main.py
# Dir: a/a02/a02q02
# Author: Carl Dalebout

import VertexSet as VertexSet


