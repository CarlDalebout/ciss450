# File:     Edges.py
# Dir:      a02/a02q02
# Author:   Carl Dalebout

class Edges:
    def __init__(self):
        pass
    def __contains__(self, u, v):
        raise NotImplementedError
    def __iter__(self):
        raise NotImplementedError
    def __str__(self):
        raise NotImplementedError