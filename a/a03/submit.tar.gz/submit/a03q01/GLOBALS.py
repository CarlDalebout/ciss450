ACTIONS = ['Left', 'Right', 'Suck']
ROOM_STATES = ['Clean', 'Dirty']
ROOMS = ['A', 'B']
