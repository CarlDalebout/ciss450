s = {'location': "A", 'room_status': 'Dirty'}
print(s['location'])