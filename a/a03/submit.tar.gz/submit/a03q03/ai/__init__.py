from basic.Object import Object
from basic.Named import Named
