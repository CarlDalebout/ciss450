class Problem:

    def __init__(self):
        pass

    def result(self, state, action):
        raise NotImplementedError
